# Vua Siêu Thị Phố — PWA v7.0

Game quản lý siêu thị pixel art, chơi offline hoàn toàn, cài được như app trên điện thoại / máy tính. Từ tạp hóa hẻm nhỏ lên đế chế bán lẻ qua 10 chương, rồi mở **Chế Độ Tự Do**.

## Cách chơi

1. **Lên kệ:** chạm vào kệ hàng (hoặc vào Kho → Lên kệ) để đưa hàng từ kho sau lên kệ.
2. **Tính tiền:** khách tự vào mua, đi ra quầy POS xếp hàng. Chạm vào POS (hoặc phím `Space`) để tính tiền hết hàng đợi. Thuê Thu Ngân thì tự tính tiền.
3. **Đặt sỉ:** hết hàng trong kho sau thì vào Kho → Đặt 1/2 lô, xe tải về sau 18 giây.
4. **Thể lực:** đi lại, lên kệ tốn thể lực. Pha cà phê (☕, 15.000đ) để hồi.
5. **Cuối ngày 22:00:** xem báo cáo P&L (doanh thu, giá vốn, tiền điện, lương, hỏng hóc) rồi sang ngày mới.
6. **Lên chương:** đủ **tài sản ròng** (tiền mặt + tiết kiệm − nợ) và đủ sao thì vào Chương → Lên chương.
7. **Phá sản:** tiền mặt âm và tài sản ròng âm → chơi lại từ chương hiện tại với 2.250.000đ.

Điều khiển: chạm / chuột, `WASD` hoặc mũi tên để di chuyển, `Space` tính tiền, `P` dừng game, `Esc` đóng menu.

## Tính năng

- **8 sản phẩm:** Rau Củ, Trái Cây, Mì Gói, Bánh Mì, Sữa Tươi, Nước Ngọt, Bánh Kẹo, Snack — mỗi món có giá vốn, giá bán, hạn hỏng, kệ riêng.
- **6 loại khách:** Vội Vã (tip cao), Khó Tính (trừ sao nhiều), VIP (mua nhiều), Trẻ Em (chỉ mua kẹo/snack), Người Già (đi chậm), Influencer (hài lòng thì mai đông khách).
- **4 nhân viên thuê được:** Thu Ngân, Nhân Viên Kho, Lao Công, Shipper — có lương/ngày, tăng cấp, sa thải.
- **Nhiệm vụ ngày + thành tựu:** thưởng tiền và xu (🪙).
- **Sự kiện ngẫu nhiên:** tủ đông đóng tuyết, đổ nước, mất điện 30s, thanh tra, khách VIP, Flash Sale 1 phút.
- **Nâng cấp:** sàn/tường 6 cấp, kệ, quầy POS, tủ lạnh, máy cà phê, biển quảng cáo.
- **Kinh tế:** vay ngân hàng, gửi tiết kiệm lấy lãi, đặt sỉ theo lô, đơn shipper, cà phê, kéo giá markup, thời tiết 1 lần/ngày (Nắng / Mưa / Lễ hội — mỗi loại có đánh đổi).
- **Chế độ:** chơi theo chương 1–10, phá đảo chương 10 mở Chế Độ Tự Do. Độ khó Dễ / Vừa / Khó, tốc độ x1/x2, nhạc + hiệu ứng WebAudio tự sinh (không file ngoài), xuất/nhập save JSON.
- **Đồ họa:** pixel art vẽ bằng canvas — ánh sáng đổi theo giờ trong ngày, bóng đổ, nhân vật nhún theo bước đi, hạt hiệu ứng (tối đa 60), mưa/nắng/lễ hội, vignette.
- **PWA:** manifest, service worker cache-first, chạy offline thật, không CDN, không font ngoài, không ảnh ngoài.

## Chạy thử trên máy

```bash
cd Vua-Sieu-Thi-PWA
python3 -m http.server 8000
# mở http://localhost:8000
```

Mở bằng `file://` thì game vẫn chạy, nhưng Service Worker (PWA/offline) chỉ chạy trên `http://localhost` hoặc `https://`.

## Up GitHub Pages (từng bước)

1. Tạo repo mới trên GitHub, ví dụ tên `vua-sieu-thi-pho` (để trống, không tick README).
2. Upload toàn bộ nội dung thư mục `Vua-Sieu-Thi-PWA` lên repo (kéo-thả trên web GitHub, hoặc):
   ```bash
   cd Vua-Sieu-Thi-PWA
   git init
   git add .
   git commit -m "Vua Sieu Thi Pho PWA v7.0"
   git branch -M main
   git remote add origin https://github.com/<ten-ban>/vua-sieu-thi-pho.git
   git push -u origin main
   ```
3. Trên GitHub: repo → **Settings → Pages** → Source: **Deploy from a branch** → Branch: `main`, Folder: `/ (root)` → Save.
4. Đợi 1–2 phút, mở `https://<ten-ban>.github.io/vua-sieu-thi-pho/` — xong. Lần đầu mở sẽ thấy nút **📲 Cài đặt app** (Chrome/Edge/Android).
5. Cập nhật bản mới: sửa file, `git add . && git commit -m "..." && git push`, Pages tự deploy lại. Nhớ đổi `CACHE` trong `sw.js` (ví dụ `vua-sieu-thi-v8`) khi đổi file, để app cũ cập nhật cache.

> Lưu ý: file `.nojekyll` đã có sẵn để GitHub Pages không bỏ qua file bắt đầu bằng `_` (nếu có).

## Cấu trúc file

```
index.html              Khung game, HUD, bottom-nav, modal, màn hình bắt đầu
manifest.webmanifest    PWA: tên, icon, màu, standalone
sw.js                   Service worker, cache-first v7, offline fallback
css/style.css           Layout, HUD, canvas, dock, responsive mobile/desktop
css/ui.css              Modal, toast, màn hình bắt đầu, báo cáo P&L
js/data.js              Sản phẩm, chương, nâng cấp, khách, nhân viên, nhiệm vụ
js/state.js             State + save/load deep-merge, version 7.0, export/import
js/audio.js             WebAudio tự sinh: click, tiền, level-up, nhạc nền
js/game.js              Vòng chơi: ngày, khách, checkout, kho, shipper, sự cố, P&L
js/render.js            Vẽ canvas 1280x720: nền, kệ, nhân vật, ánh sáng, hạt
js/ui.js                HUD, modal, toast, P&L cuối ngày, phá sản
js/main.js              Khởi tạo, game loop, input, resize, SW, install prompt
assets/icons/icon-192.png / icon-512.png
assets/favicon.svg
.nojekyll
README.md
```

## Ghi chú cân bằng (kế thừa bản 6.1/6.2)

- Điện: 100.000đ + chương × 50.000đ/ngày. Hỏng rau: 20% (tủ lạnh tốt giảm còn 5%).
- Sao: phục vụ +0,04; mất khách −0,02 → −0,08 tùy loại khách.
- Chương 1: mục tiêu tài sản ròng 4.800.000đ, 3,5 sao. Sàn/tường bắt đầu cấp 1.
- Mở modal thì game dừng (đồng hồ, khách, sự cố đều đứng yên). Thanh kéo giá chỉ lưu khi thả tay.
